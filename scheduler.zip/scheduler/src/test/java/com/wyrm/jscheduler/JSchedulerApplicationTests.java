package com.wyrm.jscheduler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JSchedulerApplicationTests {

	@Test
	void contextLoads() {
	}

}
