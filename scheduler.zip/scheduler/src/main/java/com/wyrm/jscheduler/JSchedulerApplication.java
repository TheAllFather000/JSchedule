package com.wyrm.jscheduler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JSchedulerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JSchedulerApplication.class, args);
	}

}
